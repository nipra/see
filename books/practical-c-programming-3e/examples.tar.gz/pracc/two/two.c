/*-*/
/********************************************************
 * Question:						*
 *	Why does 2+2=5986?				*
 *	(Your results may vary.)			*
 ********************************************************/
/*+*/
#include <stdio.h>

/* Variable for computation results */
int answer;

int main()
{
    answer = 2 + 2;

    printf("The answer is %d\n");
    return (0);
}
